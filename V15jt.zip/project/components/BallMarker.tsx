import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Circle, Battery } from 'lucide-react-native';

interface BallMarkerProps {
  ballName: string;
  isSelected: boolean;
  batteryLevel: number;
  signalStrength: number;
}

export function BallMarker({ ballName, isSelected, batteryLevel, signalStrength }: BallMarkerProps) {
  const getBatteryColor = (level: number) => {
    if (level > 50) return '#10B981';
    if (level > 20) return '#F59E0B';
    return '#EF4444';
  };

  const getSignalColor = (strength: number) => {
    if (strength > 70) return '#10B981';
    if (strength > 40) return '#F59E0B';
    return '#EF4444';
  };

  return (
    <View style={[styles.container, isSelected && styles.selectedContainer]}>
      <View style={[styles.ball, isSelected && styles.selectedBall]}>
        <Circle
          size={16}
          color={isSelected ? '#0EA5E9' : '#FFFFFF'}
          fill={isSelected ? '#0EA5E9' : '#FFFFFF'}
        />
      </View>
      <View style={styles.infoContainer}>
        <Text style={styles.ballName}>{ballName}</Text>
        <View style={styles.statusContainer}>
          <View style={styles.statusItem}>
            <Battery size={12} color={getBatteryColor(batteryLevel)} />
            <Text style={styles.statusText}>{batteryLevel}%</Text>
          </View>
          <View style={styles.statusItem}>
            <Circle size={8} color={getSignalColor(signalStrength)} fill={getSignalColor(signalStrength)} />
            <Text style={styles.statusText}>{signalStrength}%</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    minWidth: 80,
  },
  selectedContainer: {
    transform: [{ scale: 1.1 }],
  },
  ball: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  selectedBall: {
    backgroundColor: '#0EA5E9',
    borderColor: '#0EA5E9',
  },
  infoContainer: {
    marginTop: 4,
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  ballName: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  statusContainer: {
    flexDirection: 'row',
    gap: 6,
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  statusText: {
    fontSize: 8,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
});