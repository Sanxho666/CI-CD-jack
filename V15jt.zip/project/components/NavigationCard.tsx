import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Navigation, Square } from 'lucide-react-native';

interface NavigationCardProps {
  ballName: string;
  distance: number | null;
  isNavigating: boolean;
  onNavigate: () => void;
  onStop: () => void;
}

export function NavigationCard({ ballName, distance, isNavigating, onNavigate, onStop }: NavigationCardProps) {
  const formatDistance = (meters: number | null) => {
    if (meters === null) return '--';
    if (meters < 1000) return `${meters}m`;
    return `${(meters / 1000).toFixed(1)}km`;
  };

  return (
    <View style={styles.container}>
      <View style={styles.info}>
        <Text style={styles.ballName}>{ballName}</Text>
        <Text style={styles.distance}>{formatDistance(distance)} away</Text>
      </View>
      <TouchableOpacity
        style={[styles.button, isNavigating && styles.stopButton]}
        onPress={isNavigating ? onStop : onNavigate}
      >
        {isNavigating ? (
          <Square size={20} color="#FFFFFF" />
        ) : (
          <Navigation size={20} color="#FFFFFF" />
        )}
        <Text style={styles.buttonText}>
          {isNavigating ? 'Stop' : 'Navigate'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 16,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  info: {
    flex: 1,
  },
  ballName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  distance: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0EA5E9',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    gap: 8,
  },
  stopButton: {
    backgroundColor: '#EF4444',
  },
  buttonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});