import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Battery, Signal, Navigation, Bluetooth } from 'lucide-react-native';

interface Ball {
  id: string;
  name: string;
  connected: boolean;
  batteryLevel: number;
  signalStrength: number;
  latitude: number;
  longitude: number;
}

interface BallCardProps {
  ball: Ball;
  isSelected: boolean;
  onPress: () => void;
  onConnect: () => void;
  onNavigate: () => void;
}

export function BallCard({ ball, isSelected, onPress, onConnect, onNavigate }: BallCardProps) {
  const getBatteryColor = (level: number) => {
    if (level > 50) return '#10B981';
    if (level > 20) return '#F59E0B';
    return '#EF4444';
  };

  const getSignalColor = (strength: number) => {
    if (strength > 70) return '#10B981';
    if (strength > 40) return '#F59E0B';
    return '#EF4444';
  };

  return (
    <TouchableOpacity
      style={[styles.container, isSelected && styles.selectedContainer]}
      onPress={onPress}
    >
      <View style={styles.header}>
        <View style={styles.ballInfo}>
          <Text style={styles.ballName}>{ball.name}</Text>
          <View style={styles.statusContainer}>
            <View style={styles.statusItem}>
              <Battery size={16} color={getBatteryColor(ball.batteryLevel)} />
              <Text style={styles.statusText}>{ball.batteryLevel}%</Text>
            </View>
            <View style={styles.statusItem}>
              <Signal size={16} color={getSignalColor(ball.signalStrength)} />
              <Text style={styles.statusText}>{ball.signalStrength}%</Text>
            </View>
          </View>
        </View>
        <View style={[styles.connectionStatus, ball.connected && styles.connectedStatus]}>
          <Text style={[styles.connectionText, ball.connected && styles.connectedText]}>
            {ball.connected ? 'Connected' : 'Available'}
          </Text>
        </View>
      </View>

      {isSelected && (
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={[styles.actionButton, styles.connectButton]}
            onPress={onConnect}
          >
            <Bluetooth size={16} color="#FFFFFF" />
            <Text style={styles.actionButtonText}>
              {ball.connected ? 'Disconnect' : 'Connect'}
            </Text>
          </TouchableOpacity>
          
          {ball.connected && (
            <TouchableOpacity
              style={[styles.actionButton, styles.navigateButton]}
              onPress={onNavigate}
            >
              <Navigation size={16} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Navigate</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 12,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  selectedContainer: {
    borderWidth: 2,
    borderColor: '#0EA5E9',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ballInfo: {
    flex: 1,
  },
  ballName: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 8,
  },
  statusContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statusItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  connectionStatus: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  connectedStatus: {
    backgroundColor: '#DCFCE7',
    borderColor: '#10B981',
  },
  connectionText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#64748B',
  },
  connectedText: {
    color: '#10B981',
  },
  actionsContainer: {
    flexDirection: 'row',
    marginTop: 16,
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  connectButton: {
    backgroundColor: '#10B981',
  },
  navigateButton: {
    backgroundColor: '#0EA5E9',
  },
  actionButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});