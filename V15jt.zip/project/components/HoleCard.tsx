import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Plus, Minus } from 'lucide-react-native';

interface Hole {
  number: number;
  par: number;
  yardage: number;
  name: string;
}

interface HoleCardProps {
  hole: Hole;
  score: number;
  onScoreChange: (newScore: number) => void;
}

export function HoleCard({ hole, score, onScoreChange }: HoleCardProps) {
  const getScoreColor = () => {
    if (score === 0) return '#64748B';
    if (score < hole.par) return '#10B981';
    if (score === hole.par) return '#0EA5E9';
    return '#EF4444';
  };

  const getScoreText = () => {
    if (score === 0) return '--';
    if (score === hole.par) return 'E';
    const diff = score - hole.par;
    return diff > 0 ? `+${diff}` : diff.toString();
  };

  return (
    <View style={styles.container}>
      <View style={styles.holeInfo}>
        <Text style={styles.holeNumber}>{hole.number}</Text>
        <View style={styles.holeDetails}>
          <Text style={styles.holeName}>{hole.name}</Text>
          <Text style={styles.holeStats}>Par {hole.par} • {hole.yardage} yards</Text>
        </View>
      </View>
      
      <View style={styles.scoreContainer}>
        <TouchableOpacity
          style={styles.scoreButton}
          onPress={() => onScoreChange(Math.max(0, score - 1))}
        >
          <Minus size={16} color="#64748B" />
        </TouchableOpacity>
        
        <View style={styles.scoreDisplay}>
          <Text style={[styles.scoreValue, { color: getScoreColor() }]}>
            {score || '--'}
          </Text>
          <Text style={[styles.scoreDiff, { color: getScoreColor() }]}>
            {getScoreText()}
          </Text>
        </View>
        
        <TouchableOpacity
          style={styles.scoreButton}
          onPress={() => onScoreChange(score + 1)}
        >
          <Plus size={16} color="#64748B" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  holeInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  holeNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#10B981',
    marginRight: 16,
    minWidth: 24,
  },
  holeDetails: {
    flex: 1,
  },
  holeName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 2,
  },
  holeStats: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  scoreButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  scoreDisplay: {
    alignItems: 'center',
    minWidth: 50,
  },
  scoreValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    marginBottom: 2,
  },
  scoreDiff: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
});