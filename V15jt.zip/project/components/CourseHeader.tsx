import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Wifi, WifiOff } from 'lucide-react-native';

interface CourseHeaderProps {
  courseName: string;
  hole: number;
  par: number;
  yardage: number;
  isScanning: boolean;
}

export function CourseHeader({ courseName, hole, par, yardage, isScanning }: CourseHeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.courseInfo}>
        <Text style={styles.courseName}>{courseName}</Text>
        <View style={styles.holeInfo}>
          <Text style={styles.holeNumber}>Hole {hole}</Text>
          <Text style={styles.holePar}>Par {par}</Text>
          <Text style={styles.holeYardage}>{yardage} yards</Text>
        </View>
      </View>
      <View style={styles.statusContainer}>
        {isScanning ? (
          <Wifi size={20} color="#10B981" />
        ) : (
          <WifiOff size={20} color="#64748B" />
        )}
        <Text style={[styles.statusText, isScanning && styles.statusTextActive]}>
          {isScanning ? 'Scanning' : 'Offline'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  courseInfo: {
    flex: 1,
  },
  courseName: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 4,
  },
  holeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  holeNumber: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#10B981',
  },
  holePar: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  holeYardage: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  statusTextActive: {
    color: '#10B981',
  },
});