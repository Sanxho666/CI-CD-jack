import { useState, useEffect } from 'react';

interface Hole {
  number: number;
  par: number;
  yardage: number;
  name: string;
}

interface Game {
  id: string;
  playerName: string;
  courseName: string;
  date: string;
  scores: { [holeNumber: number]: number };
  totalScore: number;
  totalPar: number;
}

interface GameStats {
  totalScore: number;
  totalPar: number;
  holesPlayed: number;
  averageScore: number;
}

export function useScorecard() {
  const [currentGame, setCurrentGame] = useState<Game>({
    id: '',
    playerName: '',
    courseName: 'Pebble Beach Golf Links',
    date: new Date().toISOString(),
    scores: {},
    totalScore: 0,
    totalPar: 0,
  });

  const [gameHistory, setGameHistory] = useState<Game[]>([]);

  // Sample holes data - in a real app, this would come from a golf course API
  const holes: Hole[] = [
    { number: 1, par: 4, yardage: 373, name: 'First' },
    { number: 2, par: 5, yardage: 502, name: 'Second' },
    { number: 3, par: 4, yardage: 390, name: 'Third' },
    { number: 4, par: 4, yardage: 331, name: 'Fourth' },
    { number: 5, par: 3, yardage: 166, name: 'Fifth' },
    { number: 6, par: 5, yardage: 515, name: 'Sixth' },
    { number: 7, par: 3, yardage: 109, name: 'Seventh' },
    { number: 8, par: 4, yardage: 418, name: 'Eighth' },
    { number: 9, par: 4, yardage: 464, name: 'Ninth' },
    { number: 10, par: 4, yardage: 424, name: 'Tenth' },
    { number: 11, par: 4, yardage: 384, name: 'Eleventh' },
    { number: 12, par: 3, yardage: 202, name: 'Twelfth' },
    { number: 13, par: 4, yardage: 404, name: 'Thirteenth' },
    { number: 14, par: 5, yardage: 573, name: 'Fourteenth' },
    { number: 15, par: 4, yardage: 397, name: 'Fifteenth' },
    { number: 16, par: 4, yardage: 402, name: 'Sixteenth' },
    { number: 17, par: 3, yardage: 208, name: 'Seventeenth' },
    { number: 18, par: 5, yardage: 543, name: 'Eighteenth' },
  ];

  const updateHoleScore = (holeNumber: number, score: number) => {
    setCurrentGame(prev => ({
      ...prev,
      scores: {
        ...prev.scores,
        [holeNumber]: score,
      },
    }));
  };

  const calculateGameStats = (): GameStats => {
    const scores = Object.values(currentGame.scores);
    const totalScore = scores.reduce((sum, score) => sum + score, 0);
    const totalPar = holes.reduce((sum, hole) => sum + hole.par, 0);
    const holesPlayed = scores.filter(score => score > 0).length;
    const averageScore = holesPlayed > 0 ? totalScore / holesPlayed : 0;

    return {
      totalScore,
      totalPar,
      holesPlayed,
      averageScore,
    };
  };

  const saveGame = (playerName: string) => {
    const gameStats = calculateGameStats();
    const gameToSave: Game = {
      ...currentGame,
      id: Date.now().toString(),
      playerName,
      totalScore: gameStats.totalScore,
      totalPar: gameStats.totalPar,
    };

    setGameHistory(prev => [gameToSave, ...prev]);
    resetGame();
  };

  const resetGame = () => {
    setCurrentGame({
      id: '',
      playerName: '',
      courseName: 'Pebble Beach Golf Links',
      date: new Date().toISOString(),
      scores: {},
      totalScore: 0,
      totalPar: 0,
    });
  };

  const gameStats = calculateGameStats();

  return {
    currentGame,
    holes,
    gameHistory,
    gameStats,
    updateHoleScore,
    saveGame,
    resetGame,
  };
}