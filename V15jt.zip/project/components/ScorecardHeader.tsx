import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Calendar, Trophy } from 'lucide-react-native';

interface ScorecardHeaderProps {
  courseName: string;
  date: string;
  totalScore: number;
  totalPar: number;
}

export function ScorecardHeader({ courseName, date, totalScore, totalPar }: ScorecardHeaderProps) {
  const getScoreColor = () => {
    if (totalScore === 0) return '#64748B';
    if (totalScore < totalPar) return '#10B981';
    if (totalScore === totalPar) return '#0EA5E9';
    return '#EF4444';
  };

  const getScoreText = () => {
    if (totalScore === 0) return '--';
    if (totalScore === totalPar) return 'E';
    const diff = totalScore - totalPar;
    return diff > 0 ? `+${diff}` : diff.toString();
  };

  return (
    <View style={styles.container}>
      <View style={styles.courseInfo}>
        <Text style={styles.courseName}>{courseName}</Text>
        <View style={styles.dateContainer}>
          <Calendar size={16} color="#64748B" />
          <Text style={styles.date}>{date}</Text>
        </View>
      </View>
      <View style={styles.scoreContainer}>
        <View style={styles.scoreItem}>
          <Text style={[styles.scoreValue, { color: getScoreColor() }]}>
            {getScoreText()}
          </Text>
          <Text style={styles.scoreLabel}>Score</Text>
        </View>
        <View style={styles.scoreItem}>
          <Text style={styles.scoreValue}>{totalScore || '--'}</Text>
          <Text style={styles.scoreLabel}>Total</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  courseInfo: {
    flex: 1,
  },
  courseName: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 6,
  },
  dateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  date: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  scoreContainer: {
    flexDirection: 'row',
    gap: 20,
  },
  scoreItem: {
    alignItems: 'center',
  },
  scoreValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 2,
  },
  scoreLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
});