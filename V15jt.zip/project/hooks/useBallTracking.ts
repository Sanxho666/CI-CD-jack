import { useState, useEffect } from 'react';
import { Platform } from 'react-native';

interface Ball {
  id: string;
  name: string;
  connected: boolean;
  batteryLevel: number;
  signalStrength: number;
  latitude: number;
  longitude: number;
}

export function useBallTracking() {
  const [balls, setBalls] = useState<Ball[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [bleSupported, setBleSupported] = useState(true);

  useEffect(() => {
    // Check if BLE is supported on this platform
    if (Platform.OS === 'web') {
      setBleSupported(false);
      // For web demo, add some mock balls
      setBalls([
        {
          id: 'ball-1',
          name: 'Ball #1',
          connected: true,
          batteryLevel: 85,
          signalStrength: 92,
          latitude: 36.5665,
          longitude: -121.9485,
        },
        {
          id: 'ball-2',
          name: 'Ball #2',
          connected: false,
          batteryLevel: 64,
          signalStrength: 78,
          latitude: 36.5680,
          longitude: -121.9495,
        },
      ]);
    } else {
      initializeBLE();
    }
  }, []);

  const initializeBLE = async () => {
    try {
      // In a real app, this would initialize BLE manager
      // For demo purposes, we'll simulate some balls
      setBalls([
        {
          id: 'ball-1',
          name: 'Ball #1',
          connected: true,
          batteryLevel: 85,
          signalStrength: 92,
          latitude: 36.5665,
          longitude: -121.9485,
        },
        {
          id: 'ball-2',
          name: 'Ball #2',
          connected: false,
          batteryLevel: 64,
          signalStrength: 78,
          latitude: 36.5680,
          longitude: -121.9495,
        },
        {
          id: 'ball-3',
          name: 'Ball #3',
          connected: false,
          batteryLevel: 42,
          signalStrength: 55,
          latitude: 36.5655,
          longitude: -121.9475,
        },
      ]);
    } catch (error) {
      console.error('BLE initialization error:', error);
    }
  };

  const startScanning = () => {
    setIsScanning(true);
    
    // Simulate scanning for new balls
    setTimeout(() => {
      const newBall: Ball = {
        id: `ball-${Date.now()}`,
        name: `Ball #${balls.length + 1}`,
        connected: false,
        batteryLevel: Math.floor(Math.random() * 100),
        signalStrength: Math.floor(Math.random() * 100),
        latitude: 36.5665 + (Math.random() - 0.5) * 0.01,
        longitude: -121.9485 + (Math.random() - 0.5) * 0.01,
      };
      
      setBalls(prev => [...prev, newBall]);
      setIsScanning(false);
    }, 3000);
  };

  const stopScanning = () => {
    setIsScanning(false);
  };

  const connectToBall = (ballId: string) => {
    setBalls(prev => prev.map(ball => 
      ball.id === ballId ? { ...ball, connected: true } : ball
    ));
  };

  const disconnectFromBall = (ballId: string) => {
    setBalls(prev => prev.map(ball => 
      ball.id === ballId ? { ...ball, connected: false } : ball
    ));
  };

  return {
    balls,
    isScanning,
    bleSupported,
    startScanning,
    stopScanning,
    connectToBall,
    disconnectFromBall,
  };
}