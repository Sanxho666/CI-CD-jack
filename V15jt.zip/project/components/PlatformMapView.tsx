import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';

// Platform-specific imports
let MapView: any = null;
let Marker: any = null;
let Polyline: any = null;

if (Platform.OS !== 'web') {
  try {
    const Maps = require('react-native-maps');
    MapView = Maps.default;
    Marker = Maps.Marker;
    Polyline = Maps.Polyline;
  } catch (error) {
    console.warn('react-native-maps not available');
  }
}

interface PlatformMapViewProps {
  style?: any;
  region?: {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  };
  mapType?: string;
  showsUserLocation?: boolean;
  showsCompass?: boolean;
  showsScale?: boolean;
  followsUserLocation?: boolean;
  children?: React.ReactNode;
}

interface PlatformMarkerProps {
  coordinate: {
    latitude: number;
    longitude: number;
  };
  title?: string;
  description?: string;
  pinColor?: string;
  onPress?: () => void;
  children?: React.ReactNode;
}

interface PlatformPolylineProps {
  coordinates: Array<{
    latitude: number;
    longitude: number;
  }>;
  strokeColor?: string;
  strokeWidth?: number;
  lineDashPattern?: number[];
}

export function PlatformMapView({ style, region, children, ...props }: PlatformMapViewProps) {
  if (Platform.OS === 'web') {
    return (
      <View style={[styles.webMapContainer, style]}>
        <View style={styles.webMapPlaceholder}>
          <Text style={styles.webMapText}>Map View</Text>
          <Text style={styles.webMapSubtext}>
            Interactive map available on mobile devices
          </Text>
          {region && (
            <Text style={styles.webMapCoords}>
              {region.latitude.toFixed(4)}, {region.longitude.toFixed(4)}
            </Text>
          )}
        </View>
        {children}
      </View>
    );
  }

  if (!MapView) {
    return (
      <View style={[styles.errorContainer, style]}>
        <Text style={styles.errorText}>Map not available</Text>
      </View>
    );
  }

  return (
    <MapView style={style} region={region} {...props}>
      {children}
    </MapView>
  );
}

export function PlatformMarker({ coordinate, title, description, pinColor, onPress, children }: PlatformMarkerProps) {
  if (Platform.OS === 'web') {
    return (
      <View style={styles.webMarker}>
        <View style={[styles.webMarkerPin, { backgroundColor: pinColor || '#FF0000' }]} />
        {title && <Text style={styles.webMarkerTitle}>{title}</Text>}
      </View>
    );
  }

  if (!Marker) {
    return null;
  }

  return (
    <Marker
      coordinate={coordinate}
      title={title}
      description={description}
      pinColor={pinColor}
      onPress={onPress}
    >
      {children}
    </Marker>
  );
}

export function PlatformPolyline({ coordinates, strokeColor, strokeWidth, lineDashPattern }: PlatformPolylineProps) {
  if (Platform.OS === 'web') {
    return null; // Polylines not supported in web placeholder
  }

  if (!Polyline) {
    return null;
  }

  return (
    <Polyline
      coordinates={coordinates}
      strokeColor={strokeColor}
      strokeWidth={strokeWidth}
      lineDashPattern={lineDashPattern}
    />
  );
}

const styles = StyleSheet.create({
  webMapContainer: {
    backgroundColor: '#E5E7EB',
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  webMapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    backgroundColor: '#F3F4F6',
  },
  webMapText: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#374151',
    marginBottom: 8,
  },
  webMapSubtext: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 16,
  },
  webMapCoords: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#9CA3AF',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  webMarker: {
    position: 'absolute',
    alignItems: 'center',
  },
  webMarkerPin: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  webMarkerTitle: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#374151',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    marginTop: 4,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FEF2F2',
  },
  errorText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#DC2626',
  },
});